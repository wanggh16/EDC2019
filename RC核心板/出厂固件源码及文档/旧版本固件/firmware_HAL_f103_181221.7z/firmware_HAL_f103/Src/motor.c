#include "main.h"
#include "stm32f1xx_hal.h"
#include "motor.h"
#include "config.h"

static uint16_t dirpin[4] = {GPIO_PIN_13,GPIO_PIN_14,GPIO_PIN_15,GPIO_PIN_12};
typedef void (*SetOCType)(TIM_TypeDef *TIMx, uint32_t CompareValue);
static SetOCType stchs[4] = {LL_TIM_OC_SetCompareCH1,LL_TIM_OC_SetCompareCH2,LL_TIM_OC_SetCompareCH3,LL_TIM_OC_SetCompareCH4};
static uint32_t chs[4] = {LL_TIM_CHANNEL_CH1,LL_TIM_CHANNEL_CH2,LL_TIM_CHANNEL_CH3,LL_TIM_CHANNEL_CH4};
static GPIO_PinState dir[4] = {GPIO_PIN_SET,GPIO_PIN_RESET,GPIO_PIN_SET,GPIO_PIN_RESET};
static GPIO_PinState dirn[4] = {GPIO_PIN_RESET,GPIO_PIN_SET,GPIO_PIN_RESET,GPIO_PIN_SET};
static uint32_t ocpolarity[4] = {LL_TIM_OCPOLARITY_LOW,LL_TIM_OCPOLARITY_HIGH,LL_TIM_OCPOLARITY_LOW,LL_TIM_OCPOLARITY_HIGH};
static uint32_t ocpolarityn[4] = {LL_TIM_OCPOLARITY_HIGH,LL_TIM_OCPOLARITY_LOW,LL_TIM_OCPOLARITY_HIGH,LL_TIM_OCPOLARITY_LOW};
//extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim5;

/*Encoder for motor 1*/
int16_t cnt1 = 0;
/*end Encoder for motor 1*/
float currerr[4];
//int32_t speedwatch[4];
//int32_t currspeedwatch[4];
//static TIM_HandleTypeDef* encoderch[4] = {&htim2,&htim3,&htim4,&htim5};

void Motor_task(mt_ctrltype *ctrl,pidtype *mt)
{
	static uint32_t time_next = 0;
	uint32_t time_curr;
	int32_t  speed[4];
	uint8_t i;
	
	
	if(ctrl->motor_en == 0)//motors disable
		return;
	if(ctrl->pid_en == 0 )//no pid
	{
		if(ctrl->motor_update == 0)
			return;
		for(i=0;i<4;++i)
			#if REVERSE == 0
			speed[i] = mt[i].target;
			#else
			speed[i] = -mt[i].target;
			#endif
	}
	else//pid mode
	{
		time_curr = HAL_GetTick();
		if(time_curr >= time_next)
		{
			for(i=0;i<4;++i)
			{
				//currspeedwatch[i]=(float)(mt[i].cnt-mt[i].cnt_last)/(time_curr-time_next+ctrl->pid_update_period)*1000.0/3.08;
				currerr[i]=(float)mt[i].target*3.08-(float)(mt[i].cnt-mt[i].cnt_last)/(time_curr-time_next+ctrl->pid_update_period)*1000.0; //3080pps
				mt[i].err_int += currerr[i];
				mt[i].err_int = (mt[i].err_int > mt[i].intlimit)?mt[i].intlimit:mt[i].err_int;
				mt[i].err_int = (mt[i].err_int < -mt[i].intlimit)?(-mt[i].intlimit):mt[i].err_int;
				mt[i].cnt_last = mt[i].cnt;
				
				//if(currerr[i] > RBTH)
				//	speed[i] = ctrl->outlimit;
				//else if(currerr[i] < -RBTH)
				//	speed[i] = -ctrl->outlimit;
				//else
				#if MOTOR_REVERSE == 0
				//speedwatch[i]=speed[i]=currerr[i]*(mt[i].kp)+mt[i].err_int*(mt[i].ki)+(currerr[i]-mt[i].err_last)*(mt[i].kd);
				speed[i]=currerr[i]*(mt[i].kp)+mt[i].err_int*(mt[i].ki)+(currerr[i]-mt[i].err_last)*(mt[i].kd);
				
				#else
				//speedwatch[i]=speed[i]=-(currerr[i]*(mt[i].kp)+mt[i].err_int*(mt[i].ki)+(currerr[i]-mt[i].err_last)*(mt[i].kd));
				speed[i]=-(currerr[i]*(mt[i].kp)+mt[i].err_int*(mt[i].ki)+(currerr[i]-mt[i].err_last)*(mt[i].kd));
				#endif
				
				mt[i].err_last = currerr[i];
				speed[i] = (speed[i] > mt[i].outlimit)?mt[i].outlimit:speed[i];
				speed[i] = (speed[i] < -mt[i].outlimit)?(-mt[i].outlimit):speed[i];
			}
			ctrl->motor_update = 1;
			time_next = time_curr + ctrl->pid_update_period;
		}
		else
			ctrl->motor_update = 0;
	}
	if(ctrl->motor_update != 0)
	{
		for(i=0;i<4;++i)
		{
			if(speed[i] >= 0)
			{
				HAL_GPIO_WritePin(DIRBANK, dirpin[i],dir[i]);
				LL_TIM_OC_SetPolarity(DRVTIM, chs[i], ocpolarity[i]);
				speed[i] = speed[i];
			}
			else
			{
				HAL_GPIO_WritePin(DIRBANK, dirpin[i],dirn[i]);
				LL_TIM_OC_SetPolarity(DRVTIM, chs[i], ocpolarityn[i]);
				speed[i] = -speed[i];
			}
			speed[i] = (speed[i] > DUTY_MAX ? DUTY_MAX:speed[i]);
			stchs[i](DRVTIM, (uint32_t)speed[i]);
		}
		//LL_TIM_EnableAllOutputs(DRVTIM);
		ctrl->motor_update = 0;
	}
}

/*Encoder for motor 1*/
void EXTI2_IRQHandler(void)
{
	if(__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_2) != RESET)
  {
    __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_2);
		if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2) ==
				HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_15))
			++cnt1;
		else
			--cnt1;
	}
}

void EXTI15_10_IRQHandler(void)
{
	if(__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_15) != RESET)
  {
    __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_15);
		if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2) == 
				HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_15))
			--cnt1;
		else
			++cnt1;
	}
}
/*end Encoder for motor 1*/

void Get_cnt(pidtype *mt)
{

	#if ENCODER_REVERSE == 0
	mt[0].cnt += (int32_t)cnt1;
	mt[2].cnt += (int32_t)((int16_t)(__HAL_TIM_GET_COUNTER(&htim3)));
	mt[1].cnt += (int32_t)((int16_t)(__HAL_TIM_GET_COUNTER(&htim4)));
	mt[3].cnt += (int32_t)((int16_t)(__HAL_TIM_GET_COUNTER(&htim5)));
	#else
	mt[0].cnt -= (int32_t)cnt1;
	mt[2].cnt -= (int32_t)((int16_t)(__HAL_TIM_GET_COUNTER(&htim3)));
	mt[1].cnt -= (int32_t)((int16_t)(__HAL_TIM_GET_COUNTER(&htim4)));
	mt[3].cnt -= (int32_t)((int16_t)(__HAL_TIM_GET_COUNTER(&htim5)));
	#endif

	cnt1 = 0;
	LL_TIM_SetCounter(htim3.Instance, 0);
	LL_TIM_SetCounter(htim4.Instance, 0);
	LL_TIM_SetCounter(htim5.Instance, 0);

}

void Motor_PID_Enable(mt_ctrltype *ctrl,pidtype *mt)
{
	uint8_t i;
	for(i=0;i<4;++i)
	{
		mt[i].cnt_last = mt[i].cnt;
		mt[i].err_int = 0;
		mt[i].err_last = 0;
		mt[i].kp = 1.04500008;
		mt[i].ki = 0.0900062919;
		mt[i].kd = 0;
		mt[i].outlimit = 1000;
		mt[i].intlimit = 20000;
	}
	ctrl->pid_update_period = 2;
	ctrl->pid_en = 1;
}

void Motor_lock(mt_ctrltype *ctrl)
{
	uint8_t i;
	for(i=0;i<4;++i)
	{
		HAL_GPIO_WritePin(DIRBANK, dirpin[i],dir[i]);
		stchs[i](DRVTIM, 0);
		LL_TIM_OC_SetPolarity(DRVTIM, chs[i], ocpolarity[i]);
	}
	ctrl->motor_en = 0;
	ctrl->motor_update = 0;
}

void user_Motor_Init(void)
{
	LL_TIM_EnableAllOutputs(DRVTIM);
	LL_TIM_EnableCounter(DRVTIM);
	LL_TIM_CC_EnableChannel(DRVTIM, chs[0]);
	LL_TIM_CC_EnableChannel(DRVTIM, chs[1]);
	LL_TIM_CC_EnableChannel(DRVTIM, chs[2]);
	LL_TIM_CC_EnableChannel(DRVTIM, chs[3]);

	HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
	HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
	HAL_TIM_Encoder_Start(&htim5, TIM_CHANNEL_ALL);
}
