#ifndef __MECANUM_H__
#define __MECANUM_H__

void cal_mecanum(speed3axistype *speed,mt_ctrltype *ctrl,motortype *mt);

#endif
