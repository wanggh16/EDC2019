#ifndef __MOTOR_H__
#define __MOTOR_H__

#define DIRBANK GPIOB
#define DRVTIM TIM1
#define DUTY_MAX 1000
#define RBTH 100

typedef struct{
	int32_t speed;
	int32_t cnt;
	int32_t cnt_last;
	float err_last;
	float err_int;
}motortype;

typedef struct{
	uint8_t motor_en;
	uint8_t motor_update;
	uint8_t pid_en;
	uint8_t pid_update_period;
	float kp;
	float ki;
	float kd;
	int32_t outlimit;
	float intlimit;
}mt_ctrltype;

__STATIC_INLINE void Set_speed(int16_t *speedarr,mt_ctrltype *ctrl,motortype *mt)
{
	uint8_t i;
	for(i=0;i<4;++i)
	{
		mt[i].speed = speedarr[i];
	}
	if(ctrl->pid_en == 0)
		ctrl->motor_update = 1;
}



__STATIC_INLINE void Motor_PID_Disable(mt_ctrltype *ctrl)
{
	ctrl->pid_en = 0;
}

__STATIC_INLINE void Motor_unlock(mt_ctrltype *ctrl)
{
	ctrl->motor_en = 1;
}

__STATIC_INLINE void Motor_update(mt_ctrltype *ctrl)
{
	ctrl->motor_update = 1;
}

void user_Motor_Init(void);
void Motor_task(mt_ctrltype *ctrl,motortype *mt);
void Motor_lock(mt_ctrltype *ctrl);
void Get_cnt(motortype *mt);
void Motor_PID_Enable(mt_ctrltype *ctrl,motortype *mt);

#endif 
