#ifndef __CONFIG_H__
#define __CONFIG_H__

#define PID_EN 1
#define IWDG_EN 0

#define MOTOR_REVERSE 1
#define ENCODER_REVERSE 0

#define OFFLINE_DECT 1
#define TIMEOUT_TH 200 //ofline dectect ,ms

#define BAT_CHECK 1
#define BAT_TH 2100//for7.4v//7v=3.5v*2=1.75v*4 1.75/3.3*4095

#endif
