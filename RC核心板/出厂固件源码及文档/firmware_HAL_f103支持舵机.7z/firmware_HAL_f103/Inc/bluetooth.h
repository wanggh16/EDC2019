#ifndef __BLUETOOTH_H__
#define __BLUETOOTH_H__

#define UART_PORT huart2

void BT_task(mt_ctrltype *ctrl,pidtype *mt,speed3axistype *speed);

#endif
