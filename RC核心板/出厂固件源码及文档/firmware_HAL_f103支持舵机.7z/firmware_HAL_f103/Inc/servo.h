#ifndef __SERVO_H__
#define __SERVO_H__

void user_Servo_Init(void);
void Set_Servo(uint8_t servo,uint16_t pwm);

#endif
