#ifndef __BATTERY_H__
#define __BATTERY_H__

#define LOWBAT 2100

void SampleVoltage(void);
void ADC_Config(void);

#endif
