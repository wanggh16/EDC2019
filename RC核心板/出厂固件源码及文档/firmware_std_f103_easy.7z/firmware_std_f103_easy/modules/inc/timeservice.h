#ifndef __TIMESERVICE_H__
#define __TIMESERVICE_H__

void SysTick_Init(void);
void Delay_ms(uint32_t ms);
uint32_t GetTick(void);

#endif
