#ifndef __MOTOR_H__
#define __MOTOR_H__

#define PWMFREQ 18000
#define PWMACCU 1000
#define PWMMAX 999//1000-1

//void SetSpeed(int16_t *speedarray);
void Stop(void);
void Calmotorspeed(void);
void OfflineDect(void);
void PWM_Config(void);

#endif
